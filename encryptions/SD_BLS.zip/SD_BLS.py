import random
import string

def text_to_binary(text):
    binary_result = ''
    for char in text:
        # Get ASCII value and convert to binary
        binary_char = format(ord(char), '08b')  # 8-bit binary
        binary_result += binary_char
    return binary_result

def binary_to_text(binary_str):
    # Split the binary string into 8-bit chunks
    binary_values = [binary_str[i:i+8] for i in range(0, len(binary_str), 8)]
    text_result = ''.join([chr(int(b, 2)) for b in binary_values])  # Convert each binary chunk to text
    return text_result

class SD_BLS:

    @staticmethod
    def generate_key(letteramount):
        # Ensure no more than 13 letters on each side, because 26 letters total
        if letteramount > 13:
            print("Letter amount exceeds available letters, setting to 13")
            letteramount = 13
        
        # Generate a random list of letters
        letters = list(string.ascii_lowercase)
        random.shuffle(letters)
        
        # Split into two halves
        first_half = letters[:letteramount]  # Zeroes part
        second_half = letters[letteramount:letteramount*2]  # Ones part
        
        # Return the key as a single string with a colon separator
        return ''.join(first_half) + ':' + ''.join(second_half)

    @staticmethod
    def encrypt(text, key):
        # Split the key into zeroes and ones parts
        zeroes, ones = key.split(':')

        # Convert text to binary (0 for zeroes, 1 for ones)
        binary_data = text_to_binary(text)

        # Now convert binary to letters: random letter from zeroes for 0, from ones for 1
        encrypted_text = ''
        for bit in binary_data:
            if bit == '0':
                encrypted_text += random.choice(zeroes)  # Random letter from zeroes
            elif bit == '1':
                encrypted_text += random.choice(ones)  # Random letter from ones
        
        return encrypted_text

    @staticmethod
    def decrypt(text, key):
        # Split the key into zeroes and ones parts
        zeroes, ones = key.split(':')

        # Convert the encrypted text back into binary by checking the letters
        binary_data = ''
        for char in text:
            if char in zeroes:
                binary_data += '0'  # It's a zero
            elif char in ones:
                binary_data += '1'  # It's a one
        
        # Convert binary back to text
        decrypted_text = binary_to_text(binary_data)
        
        return decrypted_text

#EAG = SD_BLS()
#
#key = EAG.generate_key(13)
#print("Key:", key)
#
## Encrypting the text
#enctxt = EAG.encrypt("Hello World!", key)
#print("Enc Text:", enctxt)
#
## Encrypting again to see difference
#enctxt2 = EAG.encrypt("Hello World!", key)
#print("Enc Text2:", enctxt2)
#
## Decrypting the encrypted texts
#denctxt = EAG.decrypt(enctxt, key)
#print("Denc Text:", denctxt)  # This should print the original text after decryption
#
#denctxt2 = EAG.decrypt(enctxt2, key)
#print("Denc Text2:", denctxt2)  # This should also print the original text after decryption
#
#input("Done!. press enter to exit.")
