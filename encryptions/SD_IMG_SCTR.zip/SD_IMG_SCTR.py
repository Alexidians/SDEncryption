import uuid
import json
import random
from PIL import Image
import numpy as np
import shutil
import os

class SD_IMG_SCTR:
    def __init__(self, sdencdata):
        self.TMP_FOLDER = os.path.join(sdencdata["paths"]["encryption_path"], "tmp")  # Temporary folder for saving the encrypted image
        if not os.path.exists(self.TMP_FOLDER):
            os.makedirs(self.TMP_FOLDER)

    def text_to_binary(self, text):
        """Convert text to binary"""
        binary_result = ''
        for char in text:
            # Get ASCII value and convert to binary
            binary_char = format(ord(char), '08b')  # 8-bit binary
            binary_result += binary_char
        return binary_result

    def binary_to_text(self, binary_str):
        """Convert binary to text"""
        # Split the binary string into 8-bit chunks
        binary_values = [binary_str[i:i+8] for i in range(0, len(binary_str), 8)]
        text_result = ''.join([chr(int(b, 2)) for b in binary_values])  # Convert each binary chunk to text
        return text_result

    def encrypt(self, image_path, text_to_encrypt):
        """
        Encrypt text into the image by scattering binary 0s and 1s into random pixel locations.
        """
        # Step 1: Load the image and convert to RGB
        img = Image.open(image_path)
        img = img.convert('RGB')
        img_data = np.array(img)
        width, height = img.size
        
        # Step 2: Convert the text to binary
        binary_data = self.text_to_binary(text_to_encrypt)
        
        # Step 3: Prepare to scatter binary data
        binary_index = 0
        pixel_positions = []  # Track where binary data is placed in the image
        scattered_data = img_data.copy()  # Copy the image data to manipulate
        
        # Step 4: Find random colors not already in the image (to store binary values)
        unique_colors = set(tuple(row) for row in img_data.reshape(-1, img_data.shape[2]))
        
        # Random colors not present in the image
        binary_colors = [(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)) for _ in range(2)]
        while any(color in unique_colors for color in binary_colors):
            binary_colors = [(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)) for _ in range(2)]
        
        # Step 5: Scatter binary data randomly
        random_positions = set()
        while binary_index < len(binary_data):
            # Randomly select a position that hasn't been used yet
            random_pos = (random.randint(0, width - 1), random.randint(0, height - 1))
            if random_pos not in random_positions:
                random_positions.add(random_pos)
                current_bit = binary_data[binary_index]
                binary_index += 1
                # Set the pixel to one of the binary colors based on the bit
                if current_bit == '0':
                    scattered_data[random_pos[1], random_pos[0]] = binary_colors[0]  # Store 0 as first color
                else:
                    scattered_data[random_pos[1], random_pos[0]] = binary_colors[1]  # Store 1 as second color
                pixel_positions.append({"x": random_pos[0], "y": random_pos[1]})

        # Step 6: Save the encrypted image to the tmp folder with a unique name
        tmp_image_name = f"{str(uuid.uuid4())}.png"
        tmp_image_path = f"{self.TMP_FOLDER}/{tmp_image_name}"
        encrypted_img = Image.fromarray(scattered_data)
        encrypted_img.save(tmp_image_path)

        # Step 7: Prepare the key (JSON format) with the RGB colors and pixel positions
        key_data = {
            "binary_colors": binary_colors,  # Colors used to store binary data
            "positions": [{"x": pos["x"], "y": pos["y"]} for pos in pixel_positions]  # Pixel positions where binary data was stored
        }

        # Return the path and stringified JSON key containing binary_colors and positions
        key_json = json.dumps(key_data, separators=(',', ':'))
        return tmp_image_path, key_json

    def decrypt(self, encrypted_image_path, key_json):
        """
        Decrypt binary data from an encrypted image based on the key.
        """
        # Load image and extract key data
        encrypted_img = Image.open(encrypted_image_path)
        encrypted_img_data = np.array(encrypted_img)
        
        key_data = json.loads(key_json)
        binary_colors = tuple(tuple(c) for c in key_data['binary_colors'])
        
        binary_result = []

        # Step 1: For each pixel, check if it matches one of the binary colors
        for pos in key_data['positions']:
            x, y = pos["x"], pos["y"]
            current_pixel = tuple(encrypted_img_data[y, x])

            if current_pixel == binary_colors[0]:
                binary_result.append('0')
            elif current_pixel == binary_colors[1]:
                binary_result.append('1')

        # Step 2: Combine binary data and convert back to text
        binary_str = ''.join(binary_result)
        decrypted_text = self.binary_to_text(binary_str)
        
        return decrypted_text



## Example Usage
#EAG = SD_IMG_SCTR()
#image_path = 'xp.png'  # Replace with the actual image path
#
#text_to_encrypt = "Hello World! this is in a PNG image"
#tmp_image_path, key_json = EAG.image_encrypt(image_path, text_to_encrypt)
#print("Encrypted Image Path:", tmp_image_path)
#print("Key (for decryption):", key_json)
#
## To decrypt
#decrypted_text = EAG.image_decrypt(tmp_image_path, key_json)
#print("Decrypted Text:", decrypted_text)
