import os
import threading
import subprocess

ENCRYPTIONS_DIR = os.path.abspath("encryptions")
os.makedirs(ENCRYPTIONS_DIR, exist_ok=True)

# Function to import the library and return the class
def import_encryption(name):
    # Build the path to the library folder and script file
    libfolder_path = os.path.abspath(os.path.join(ENCRYPTIONS_DIR, name))
    libscriptfile_path = os.path.abspath(os.path.join(libfolder_path, name + ".py"))
    
    # Check if the library folder and script exist
    if os.path.exists(libscriptfile_path):
        # Create an event to communicate the result back
        result_event = threading.Event()
        result = [None]  # Using a list to store the result (can be used for mutation in threads)
        
        thread = threading.Thread(target=execute_script, args=(libfolder_path, libscriptfile_path, result_event, result))
        thread.start()
        
        # Wait for the thread to finish and return the result (the class)
        result_event.wait()
        
        # Return the class from the library
        return result[0]
    else:
        print(f"Library '{name}' not found at {libscriptfile_path}.")
        return None

# Function to execute the script and return the class
def execute_script(libfolder_path, libscriptfile_path, result_event, result):
    import inspect
    import importlib
    # Create a new context for the current thread and change the directory for this thread only
    original_directory = os.getcwd()  # Save the current directory
    
    try:
        # Change directory just for this thread's execution
        os.chdir(libfolder_path)
        
        # Open the script file and read its content
        with open(os.path.abspath(libscriptfile_path), 'r') as libscriptfile:
            libscript = libscriptfile.read()
        
        # Execute the script content in the current thread's context
        exec(libscript, globals())  # 'globals()' to access the global context of this thread
        sdlibdata = {
            "paths": {
                "encryption_path": libfolder_path,
                "sdencryption_cwd": original_directory
            }
        }
        if inspect.isfunction(globals().get(os.path.basename(libfolder_path))):
            sig = inspect.signature(globals().get(os.path.basename(libfolder_path)))
            if "sdencdata" in sig.parameters:
                library_class = globals().get(os.path.basename(libfolder_path))(sdencdata=sdlibdata)
            else:
                library_class = globals().get(os.path.basename(libfolder_path))()
        else:
            sig = inspect.signature(getattr(globals().get(os.path.basename(libfolder_path)), '__init__'))
            if "sdencdata" in sig.parameters:
                library_class = globals().get(os.path.basename(libfolder_path))(sdencdata=sdlibdata)
            else:
                library_class = globals().get(os.path.basename(libfolder_path))()
        
        # If the class is found, store it in the result list
        if library_class:
            result[0] = library_class
        else:
            result[0] = None
        
        print(f"Encryption '{libfolder_path}' imported successfully in thread.")
    
    except Exception as e:
        print(f"Error while importing Encryption: {e}")
        result[0] = None
    
    finally:
        # Revert to the original directory after script execution
        os.chdir(original_directory)
        
        # Signal that the thread is done
        result_event.set()

class SDEncryption():
    def __init__(self, sdlibdata):
        ENCRYPTIONS_DIR = os.path.join(sdlibdata["paths"]["libfolder_path"], "encryptions")
        self.import_encryption = import_encryption